# product-review

A simple product or service review app built with HTML, CSS, Javascript, Bootstrap, chart.js and Jquery.
